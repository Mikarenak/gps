<?php

namespace App\Http\Controllers;

use App\Models\AbsenKendaraan;
use App\Models\AbsenKendaraanDetail;
use App\Models\AbsenKendaraanKeterangan;
use App\Models\AbsenKendaraanSaldo;
use App\Models\Daerah;
use App\Models\Symbol;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Request;

class AbsenKendaraanController extends BaseController
{
    public function index(Request $request, $namaDaerah)
    {
        if (!empty($namaDaerah)) {
            if ($daerah = Daerah::where('code_daerah', $namaDaerah)->first()) {
                $listAbsenKendaraan = AbsenKendaraan::with('keteranganKendaraan.saldo', 'keteranganKendaraan.detail')->where('id_daerah', $daerah->id)->get();
                $symbols = Symbol::get();
                $startDate = !empty($request->start) ? $request->start : Carbon::now()->format('Y-m-d');
                $endDate = !empty($request->end) ? $request->end : Carbon::now()->addDays(7)->format('Y-m-d');
                $dates = CarbonPeriod::create($startDate, $endDate)->toArray();
                return view('dashboard', compact('listAbsenKendaraan', 'symbols', 'daerah', 'startDate', 'endDate', 'dates'));
            }
        }
        return 'This Page does not exist';
    }

    public function indexAdd(Request $request, $namaDaerah)
    {
        if (!empty($namaDaerah)) {
            if ($daerah = Daerah::where('code_daerah', $namaDaerah)->first()) {
                return view('kendaraan.add-kendaraan', compact('daerah'));
            }
        }
        return 'This Page does not exist';
    }

    public function indexEdit(Request $request, $namaDaerah, $IDabsenKendaraan)
    {
        if (!empty($namaDaerah)) {
            $daerah = Daerah::where('code_daerah', $namaDaerah)->first();
            $absenKendaraan = AbsenKendaraan::find($IDabsenKendaraan);

            if (!empty($absenKendaraan) && !empty($daerah)) {
                return view('kendaraan.edit-kendaraan', compact('daerah', 'absenKendaraan'));
            }
        }
        return 'This Page does not exist';
    }

    public function indexPrint(Request $request, $namaDaerah)
    {
        if (!empty($namaDaerah) && !empty($request->start) && !empty($request->end)) {
            if ($daerah = Daerah::where('code_daerah', $namaDaerah)->first()) {
                $listAbsenKendaraan = AbsenKendaraan::with('keteranganKendaraan.saldo', 'keteranganKendaraan.detail')->where('id_daerah', $daerah->id)->get();
                $symbols = Symbol::get();
                $startDate =  $request->start;
                $endDate = $request->end;
                $dates = CarbonPeriod::create($startDate, $endDate)->toArray();

                return view('kendaraan.print-absen-kendaraan', compact('listAbsenKendaraan', 'symbols', 'daerah', 'startDate', 'endDate', 'dates'));
            }
        }
        return 'This Page does not exist';
    }

    public function actionEditKendaraan(Request $request)
    {
        $x = $request->validate([
            'id_absen_kendaraan' => ['required'],
            'code_daerah' => ['required'],
            'nopol' => ['required'],
            'nm_supir' => ['required'],
        ]);

        if ($absenKendaraan = AbsenKendaraan::where('id', $request->id_absen_kendaraan)->first()) {
            $absenKendaraan->nopol = $request->nopol;
            $absenKendaraan->nm_supir = $request->nm_supir;
            $absenKendaraan->save();
            return redirect('/dashboard/absensi/' . $request->code_daerah)->with('success', 'Berhasil Mengupdate Kendaraan');
        }

        return redirect('/dashboard/absensi/' . $request->code_daerah)->with('success', 'Gagal Mengupdate Kendaraan');
    }

    public function actionAddKendaraan(Request $request)
    {
        $x = $request->validate([
            'nopol' => ['required'],
            'nm_supir' => ['required'],
            'id_daerah' => ['required'],
            'code_daerah' => ['required'],
        ]);

        DB::beginTransaction();
        try {
            $absenKendaraan = new AbsenKendaraan;
            $absenKendaraan->id_daerah = $request->id_daerah;
            $absenKendaraan->nopol = $request->nopol;
            $absenKendaraan->nm_supir = $request->nm_supir;
            $absenKendaraan->save();

            $particularArea = ['perak-40', 'lk-ch', 'perak-20'];
            if (in_array($request->code_daerah, $particularArea)) {
                $keterangan = ['MT', 'Sangu', 'GPS', 'GPS'];
            } else {
                $keterangan = ['MT', 'Sangu', 'GPS'];
            }

            for ($i = 0; $i < count($keterangan); $i++) {
                $absenKendaraanKeterangan = new AbsenKendaraanKeterangan;
                $absenKendaraanKeterangan->id_absen_kendaraan = $absenKendaraan->id;
                $absenKendaraanKeterangan->nm_keterangan = $keterangan[$i];
                $absenKendaraanKeterangan->seq = $i + 1;
                $absenKendaraanKeterangan->save();
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return redirect('/dashboard/absensi/' . $request->code_daerah)->with('failed', 'Gagal Menambahkan Kendaraan');
        }

        return redirect('/dashboard/absensi/' . $request->code_daerah)->with('success', 'Berhasil Menambahkan Kendaraan');
    }

    public function actionPresence(Request $request)
    {
        $absenKendaraanDetail = new AbsenKendaraanDetail;
        $absenKendaraanDetail->id_absen_kendaraan = $request->id_absen_kendaraan;
        $absenKendaraanDetail->id_absen_kendaraan_keterangan = $request->id_absen_kendaraan_keterangan;
        $absenKendaraanDetail->warna_symbol = $request->warna_symbol;
        $absenKendaraanDetail->nm_keterangan = $request->nm_keterangan;
        $absenKendaraanDetail->nilai = $request->nilai;
        $absenKendaraanDetail->alasan = $request->alasan;
        $absenKendaraanDetail->tanggal_absen = $request->date;
        $absenKendaraanDetail->save();
    }

    public function actionEditPresence(Request $request)
    {
        if ($absenKendaraanDetail = AbsenKendaraanDetail::where('id_absen_kendaraan', $request->id_absen_kendaraan)
            ->where('id_absen_kendaraan_keterangan', $request->id_absen_kendaraan_keterangan)
            ->where('tanggal_absen', $request->date)->first()
        ) {
            $absenKendaraanDetail->nm_keterangan = $request->nm_keterangan;
            $absenKendaraanDetail->warna_symbol = $request->warna_symbol;
            $absenKendaraanDetail->nilai = $request->nilai;
            $absenKendaraanDetail->alasan = $request->alasan;
            $absenKendaraanDetail->tanggal_absen = $request->date;
            $absenKendaraanDetail->save();
        }
    }
    public function actionBulkCopyPresence(Request $request)
    {
        if ($absenKendaraanDetail = AbsenKendaraanDetail::where('id_absen_kendaraan', $request->id_absen_kendaraan)
            ->where('id_absen_kendaraan_keterangan', $request->id_absen_kendaraan_keterangan)
            ->where('tanggal_absen', $request->date)->first()
        ) {
            $absenKendaraanDetail->nm_keterangan = $request->nm_keterangan;
            $absenKendaraanDetail->warna_symbol = $request->warna_symbol;
            $absenKendaraanDetail->nilai = $request->nilai;
            $absenKendaraanDetail->alasan = $request->alasan;
            $absenKendaraanDetail->tanggal_absen = $request->date;
            $absenKendaraanDetail->save();
        } else {
            return ['statusCode' => 201, 'message' => 'Gagal copy absen!'];
        }

        $dates = CarbonPeriod::create($request->start_date, $request->end_date)->toArray();
        foreach ($dates as $date) {
            if (AbsenKendaraanDetail::where('id_absen_kendaraan', $request->id_absen_kendaraan)
                ->where('id_absen_kendaraan_keterangan', $request->id_absen_kendaraan_keterangan)
                ->where('tanggal_absen', $date)->doesntExist()
            ) {
                $absenKendaraanDetail = new AbsenKendaraanDetail;
                $absenKendaraanDetail->id_absen_kendaraan = $request->id_absen_kendaraan;
                $absenKendaraanDetail->id_absen_kendaraan_keterangan = $request->id_absen_kendaraan_keterangan;
                $absenKendaraanDetail->warna_symbol = $request->warna_symbol;
                $absenKendaraanDetail->nm_keterangan = $request->nm_keterangan;
                $absenKendaraanDetail->nilai = $request->nilai;
                $absenKendaraanDetail->alasan = $request->alasan;
                $absenKendaraanDetail->tanggal_absen = $date->format('Y-m-d');
                $absenKendaraanDetail->save();
            }
        }
        return ['statusCode' => 200, 'message' => 'Sukses copy absen!'];
    }
    public function actionAddBalance(Request $request)
    {
        $absenKendaraanSaldo = new AbsenKendaraanSaldo;
        $absenKendaraanSaldo->id_absen_kendaraan = $request->id_absen_kendaraan;
        $absenKendaraanSaldo->id_absen_kendaraan_keterangan = $request->id_absen_kendaraan_keterangan;
        $absenKendaraanSaldo->saldo = $request->saldo;
        $absenKendaraanSaldo->save();
    }
}
