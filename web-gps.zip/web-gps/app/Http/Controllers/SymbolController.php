<?php

namespace App\Http\Controllers;

use App\Models\Daerah;
use App\Models\Symbol;
use Illuminate\Routing\Controller as BaseController;
use Symfony\Component\HttpFoundation\Request;

class SymbolController extends BaseController
{
    public function indexAdd(Request $request, $namaDaerah)
    {
        if (!empty($namaDaerah)) {
            if ($daerah = Daerah::where('code_daerah', $namaDaerah)->first()) {
                return view('symbol.add-symbol', compact('daerah'));
            }
        }
        return 'This Page does not exist';
    }

    public function indexEdit(Request $request, $namaDaerah, $IDsymbol)
    {
        if (!empty($namaDaerah)) {
            $daerah = Daerah::where('code_daerah', $namaDaerah)->first();
            $symbol = Symbol::where('id', $IDsymbol)->first();

            if (!empty($daerah) && !empty($symbol)) {
                return view('symbol.edit-symbol', compact('daerah', 'symbol'));
            }
        }
        return 'This Page does not exist';
    }

    public function actionAddSymbol(Request $request)
    {
        $x = $request->validate([
            'code_daerah' => ['required'],
            'nm_symbol' => ['required'],
            'ket_symbol' => ['required'],
            'warna_symbol' => ['required'],
            // 'value' => ['required'],
        ]);

        $symbol = new Symbol;
        $symbol->nm_symbol = $request->nm_symbol;
        $symbol->ket_symbol = $request->ket_symbol;
        $symbol->warna_symbol = $request->warna_symbol;
        // $symbol->value = $request->value;
        $symbol->save();

        return redirect('/dashboard/absensi/' . $request->code_daerah)->with('success', 'Berhasil Menambahkan Symbol');
    }

    public function actionEditSymbol(Request $request)
    {
        $x = $request->validate([
            'code_daerah' => ['required'],
            'nm_symbol' => ['required'],
            'ket_symbol' => ['required'],
            'warna_symbol' => ['required'],
            'value' => ['required'],
        ]);

        $symbol = new Symbol;
        $symbol->nm_symbol = $request->nm_symbol;
        $symbol->ket_symbol = $request->ket_symbol;
        $symbol->warna_symbol = $request->warna_symbol;
        $symbol->value = $request->value;
        $symbol->save();

        return redirect('/dashboard/absensi/' . $request->code_daerah)->with('success', 'Berhasil Menambahkan Symbol');
    }
}
