<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Request;

class UserController extends BaseController
{
    public function index(Request $request)
    {
        if (Auth::check()) {
            return redirect('/dashboard');
        }
        return view('sign-in');
    }

    public function actionSignIn(Request $request)
    {
        $x = $request->validate([
            'username' => ['required'],
            'password' => ['required'],
        ]);

        if ($user = User::where(['username' => $request->username])->first()) {
            if (Hash::check($request->password, $user->password)) {
                Auth::attempt(["username" => $request->username, "password" => $request->password]);
                $request->session()->regenerate();
                return redirect('/dashboard');
            }
        }
        return back()->with('failed', 'Username atau Password salah');
    }

    public function actionSignOut(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();
        return redirect('/');
    }
}
