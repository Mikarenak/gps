<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AbsenKendaraan extends Model
{
  protected $table = 'absen_kendaraan';

  protected $primaryKey = 'id';

  public $timestamps = true;

  public $incrementing = true;

  protected $guarded = [];

  public function keteranganKendaraan()
  {
    return $this->hasMany(AbsenKendaraanKeterangan::class, 'id_absen_kendaraan');
  }
}
