<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AbsenKendaraanDetail extends Model
{
  protected $table = 'absen_kendaraan_detail';

  protected $primaryKey = 'id';

  public $timestamps = true;

  public $incrementing = true;

  protected $guarded = [];

  // public function symbol()
  // {
  //   return $this->hasOne(Symbol::class, 'id', 'id_symbol');
  // }
}
