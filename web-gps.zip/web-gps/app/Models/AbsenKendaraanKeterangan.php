<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AbsenKendaraanKeterangan extends Model
{
  protected $table = 'absen_kendaraan_keterangan';

  protected $primaryKey = 'id';

  public $timestamps = true;

  public $incrementing = true;

  protected $guarded = [];

  public function saldo()
  {
    return $this->hasOne(AbsenKendaraanSaldo::class, 'id_absen_kendaraan_keterangan');
  }

  public function detail()
  {
    return $this->hasMany(AbsenKendaraanDetail::class, 'id_absen_kendaraan_keterangan');
  }
}
