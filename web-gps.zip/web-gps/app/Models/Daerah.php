<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Daerah extends Model
{
    protected $table = 'daerah';

    protected $primaryKey = 'id';

    public $timestamps = true;

    public $incrementing = true;

    protected $guarded = [];
}
