<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Symbol extends Model
{
  protected $table = 'symbol';

  protected $primaryKey = 'id';

  public $timestamps = true;

  public $incrementing = true;

  protected $guarded = [];
}
