<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('absen_kendaraan_detail', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('id_absen_kendaraan');
            $table->bigInteger('id_absen_kendaraan_keterangan');
            $table->bigInteger('id_symbol');
            $table->tinyInteger('seq');
            $table->string('nm_keterangan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('absen_kendaraan_detail');
    }
};
