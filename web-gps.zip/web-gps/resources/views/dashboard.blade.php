@extends('layouts.app')
@section('content')
    <style>
        table>tbody>tr:nth-child(1) {
            background: #9D3C72;
            color: white;
        }
    </style>
    @if (session()->has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
        </div>
    @endif
    @if (session()->has('failed'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('failed') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
        </div>
    @endif
    <div class ="mb-3">
            <h4 style="color:black;font-weight: bolder;">Kelompok {{ $daerah->nm_daerah }}</h4>
    <div>
    <div class=" my-3 justify-content-between mb-3">
        <div class="row g-2">
            <div class="col-md">
                <div class="form-floating">
                    <input type="date" class="form-control" name="start_date" value="{{ $startDate }}"
                        id="floatingInputGrid">
                    <label for="floatingInputGrid">Start Date</label>
                </div>
            </div>
            <div class="col-md">
                <div class="form-floating">
                    <input type="date" class="form-control" name="end_date" value="{{ $endDate }}"
                        id="floatingInputGrid">
                    <label for="floatingInputGrid">End Date</label>
                </div>
            </div>
            <div class="col-md">
                <div class="form-floating">
                    <button type="button" class="btn btn-secondary" onclick="changeDateAction()">Change Date</button>
                </div>
            </div>
        </div>
    </div>
    <div class="d-flex justify-content-between mb-3">
        <a href="/dashboard/absensi/{{ $daerah->code_daerah }}/print?start={{ $startDate }}&end={{ $endDate }}"
            target="_blank" rel="noopener noreferrer" type="button" class="btn btn-main">Print</a>
        <div></div>
        <a href="/dashboard/absensi/{{ $daerah->code_daerah }}/add-kendaraan" type="button" class="btn btn-main">
            <i class="bi bi-plus-lg"></i> Tambah Kendaraan</a>
    </div>
    <div style="overflow-x: scroll">
        <table class="table table-bordered table-responsive" id="absen-kendaraan-table">
            <tr>
                <td>NO</td>
                <td>NOPOL</td>
                <td>Supir</td>
                <td>KET</td>
                <td>SALDO</td>
                @foreach ($dates as $date)
                    <td>{{ $date->format('d') }}</td>
                @endforeach
            </tr>
            @foreach ($listAbsenKendaraan as $absenKendaraan)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td><a class="link-dark"
                            href="/dashboard/absensi/{{ $daerah->code_daerah }}/edit-kendaraan/{{ $absenKendaraan->id }}">{{ $absenKendaraan->nopol }}</a>
                    </td>
                    <td>{{ $absenKendaraan->nm_supir }}</td>
                    @php
                        $keterangan = $absenKendaraan->keteranganKendaraan->where('seq', 1)->first();
                    @endphp
                    <td>{{ $keterangan->nm_keterangan }}</td>
                    @if (!empty($keterangan->saldo))
                        <td>{{ $keterangan->saldo->saldo }}</td>
                    @else
                        <td style="cursor: pointer" onclick="showBalanceInput(this)">
                            <input type="number" class="d-none">
                            <button type="button" class="btn btn-main btn-sm mt-2 d-none"
                                onclick="inputBalanceAction(this,{{ $absenKendaraan->id }},{{ $keterangan->id }})">Save</button>
                        </td>
                    @endif
                    @foreach ($dates as $key => $value)
                        @if (!empty($keterangan->detail))
                            @php
                                $absen = $keterangan->detail->where('tanggal_absen', $value->format('Y-m-d'))->first();
                            @endphp
                            @if (!empty($absen))
                                <td style="cursor: pointer" id='{{ uniqid('absen-kendaraan-') }}'
                                    onclick="showEditPresenceModal(this,'{{ $absenKendaraan->id }}','{{ $keterangan->id }}','{{ $absen->nm_keterangan }}','{{ $absen->warna_symbol }}','{{ $absen->nilai }}','{{ $absen->alasan }}','{{ $value->format('Y-m-d') }}')">
                                    <div style="background:{{ $absen->warna_symbol }};padding:10px">
                                        {{ $absen->nm_keterangan }}</div>
                                    <div style="width: 70px;word-wrap: break-word">
                                        @if (!empty($absen->alasan))
                                            <span>Alasan: <b>{{ $absen->alasan }}</b></span>
                                        @endif
                                    </div>
                                </td>
                            @else
                                <td style="cursor: pointer" id='{{ uniqid('absen-kendaraan-') }}'
                                    onclick="showPresenceModal(this,'{{ $absenKendaraan->id }}','{{ $keterangan->id }}','{{ $value->format('Y-m-d') }}')">
                                </td>
                            @endif
                        @else
                            <td></td>
                        @endif
                    @endforeach
                </tr>
                @foreach ($absenKendaraan->keteranganKendaraan->sortBy('seq') as $keterangan)
                    @if (!$loop->first)
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>{{ $keterangan->nm_keterangan }}</td>
                            @if (!empty($keterangan->saldo))
                                <td>{{ $keterangan->saldo->saldo }}</td>
                            @else
                                <td style="cursor: pointer" onclick="showBalanceInput(this)">
                                    <input type="number" class="d-none">
                                    <button type="button" class="btn btn-secondary btn-sm mt-2 d-none"
                                        onclick="inputBalanceAction(this,{{ $absenKendaraan->id }},{{ $keterangan->id }})">Save</button>
                                </td>
                            @endif
                            @foreach ($dates as $key => $value)
                                @if (!empty($keterangan->detail))
                                    @php
                                        $absen = $keterangan->detail->where('tanggal_absen', $value->format('Y-m-d'))->first();
                                    @endphp
                                    @if (!empty($absen))
                                        <td style="cursor: pointer;" id='{{ uniqid('absen-kendaraan-') }}'
                                            onclick="showEditPresenceModal(this,'{{ $absenKendaraan->id }}','{{ $keterangan->id }}','{{ $absen->nm_keterangan }}','{{ $absen->warna_symbol }}','{{ $absen->nilai }}','{{ $absen->alasan }}','{{ $value->format('Y-m-d') }}')">
                                            <div style="background:{{ $absen->warna_symbol }};padding:10px">
                                                {{ $absen->nm_keterangan }}
                                            </div>
                                            <div style="width: 70px;word-wrap: break-word">
                                                @if (!empty($absen->alasan))
                                                    <span>Alasan: <b>{{ $absen->alasan }}</b></span>
                                                @endif
                                            </div>
                                        </td>
                                    @else
                                        <td style="cursor: pointer" id='{{ uniqid('absen-kendaraan-') }}'
                                            onclick="showPresenceModal(this,'{{ $absenKendaraan->id }}','{{ $keterangan->id }}','{{ $value->format('Y-m-d') }}')">
                                        </td>
                                    @endif
                                @else
                                    <td></td>
                                @endif
                            @endforeach
                        </tr>
                    @endif
                @endforeach
            @endforeach
        </table>
    </div>
    <div class="mt-4">
        <h3>Keterangan Simbol</h3>
        <div class="row row-cols-2 mt-3">
            @foreach ($symbols as $symbol)
                <div class="col d-flex text-center mb-1">
                    <div class="me-2" style="width:50px;height:40px;background:{{ $symbol->warna_symbol }}">
                        {{ $symbol->nm_symbol }}
                    </div>
                    <span>:</span>
                    <a class="link-dark"
                        href="/dashboard/absensi/{{ $daerah->code_daerah }}/edit-symbol/{{ $symbol->id }}">{{ $symbol->ket_symbol }}</a>
                </div>
            @endforeach
        </div>
        <a href="/dashboard/absensi/{{ $daerah->code_daerah }}/add-symbol" class="mt-3 btn btn-main">+</a>
    </div>

    <div class="modal fade" id="absenActionModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Absen Kendaraan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Keterangan <small
                                style="color:red">*</small></label>
                        <input type="text" class="form-control" name="keterangan">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Warna Symbol <small
                                style="color:red">*</small></label>
                        {{-- <input type="color" class="form-control form-control-color" name="warna_symbol"
                            id="exampleFormControlInput1"> --}}
                        <select class="form-select" name="warna_symbol">
                            @foreach ($symbols as $symbol)
                                <option value="{{ $symbol->warna_symbol }}"
                                    style="background: {{ $symbol->warna_symbol }}">
                                    {{ $symbol->ket_symbol }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Nilai Symbol <small
                                style="color:red">*</small></label>
                        <input type="number" class="form-control" name="nilai_symbol" id="exampleFormControlInput1">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Alasan</label>
                        <textarea class="form-control" name="alasan" rows="3"></textarea>
                    </div>
                    <div id="copy-absen-field">
                        <hr>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="toggle-copy-absen">
                            <label class="form-check-label" for="flexCheckDefault">
                                <b>Ingin Copy Absen ?</b>
                            </label>
                        </div>
                        <h5 class="my-3">Copy Absen</h5>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">Start Date<small
                                    style="color:red">*</small></label>
                            <input type="date" class="form-control" name="bulk_copy_start_date"
                                value="{{ $startDate }}" disabled>
                            <label for="floatingInputGrid">Start Date</label>
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">End Date<small
                                    style="color:red">*</small></label>
                            <input type="date" class="form-control" value="{{ $endDate }}" disabled
                                name="bulk_copy_end_date" id="exampleFormControlInput1">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-main" id="absen-btn-action">Save
                        changes</button>
                </div>
            </div>
        </div>
    </div>
    @push('script')
        <script>
            $('#toggle-copy-absen').change(function() {
                if ($(this).prop('checked')) {
                    $("input[name=bulk_copy_start_date]").removeAttr('disabled');
                    $("input[name=bulk_copy_end_date]").removeAttr('disabled');
                } else {
                    $("input[name=bulk_copy_start_date]").attr('disabled', 'disabled');
                    $("input[name=bulk_copy_end_date]").attr('disabled', 'disabled');
                }
            })

            function showEditPresenceModal(element, IDabsenKendaraan, IDketeranganKendaraan, keterangan, warnaSymbol,
                nilaiSymbol, alasan, date) {
                const elementID = $(element).attr('id');
                $(`#copy-absen-field`).removeClass('d-none');
                $('#absenActionModal').modal('show');
                $("input[name=keterangan]").val(keterangan);
                $("select[name=warna_symbol]").val(warnaSymbol);
                $("input[name=nilai_symbol]").val(nilaiSymbol);
                $("textarea[name=alasan]").val(alasan);
                $('.modal-title').text('Edit Absen Kendaraan');
                $('#absen-btn-action').attr('onClick',
                    `editPresenceAction("${elementID}","${IDabsenKendaraan}","${IDketeranganKendaraan}","${date}")`);
            }

            function showPresenceModal(element, IDabsenKendaraan, IDketeranganKendaraan, date) {
                const elementID = $(element).attr('id');
                $(`#copy-absen-field`).addClass('d-none');
                $('.modal-title').text('Tambah Absen Kendaraan');
                $("input[name=keterangan]").val('');
                $("select[name=warna_symbol]").val('');
                $("input[name=nilai_symbol]").val('');
                $("textarea[name=alasan]").val('');
                $('#absenActionModal').modal('show');
                $('#absen-btn-action').attr('onClick',
                    `presenceAction("${elementID}","${IDabsenKendaraan}","${IDketeranganKendaraan}","${date}")`
                );
            }

            function showBalanceInput(element) {
                const x = $(element);
                x.children().removeClass('d-none');
            }

            function editPresenceAction(ID, IDabsenKendaraan, IDketeranganKendaraan, date) {
                const element = $(`#${ID}`)
                const keterangan = $("input[name=keterangan]").val();
                const warnaSymbol = $("select[name=warna_symbol]").val();
                const nilaiSymbol = $("input[name=nilai_symbol]").val();
                const alasan = $("textarea[name=alasan]").val();
                const bulkCopyStartDate = $("input[name=bulk_copy_start_date]").val();
                const bulkCopyEndDate = $("input[name=bulk_copy_end_date]").val();
                const isBulkCopy = $('#toggle-copy-absen').prop('checked');

                if (!keterangan && !warnaSymbol && !nilaiSymbol) {
                    alert('Harap isi absen dengan benar')
                    return;
                }
                if (isBulkCopy && bulkCopyEndDate && bulkCopyStartDate) {
                    bulkCopyPresenceAction(IDabsenKendaraan, IDketeranganKendaraan, bulkCopyStartDate, bulkCopyEndDate, date)
                    return;
                }
                const html =
                    `<div style="background:${warnaSymbol};padding:10px">${keterangan}</div><div>${alasan ? `Alasan : <b>${alasan}</b>` :``}</div>`
                $('#absenActionModal').modal('hide');
                element.html(html);
                element.attr('onClick',
                    `showEditPresenceModal(this,"${IDabsenKendaraan}","${IDketeranganKendaraan}","${keterangan}","${warnaSymbol}","${nilaiSymbol}","${alasan}","${date}")`
                );
                $.ajax({
                    type: 'POST',
                    url: '/act/edit-presence',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        id_absen_kendaraan: IDabsenKendaraan,
                        id_absen_kendaraan_keterangan: IDketeranganKendaraan,
                        nm_keterangan: keterangan,
                        warna_symbol: warnaSymbol,
                        nilai: nilaiSymbol,
                        alasan: alasan,
                        date: date,
                    },
                    error: function() {
                        element.text('').css('background', 'white');
                    }

                });
            }

            function bulkCopyPresenceAction(IDabsenKendaraan, IDketeranganKendaraan, startDate, endDate, date) {
                const keterangan = $("input[name=keterangan]").val();
                const warnaSymbol = $("select[name=warna_symbol]").val();
                const nilaiSymbol = $("input[name=nilai_symbol]").val();
                const alasan = $("textarea[name=alasan]").val();
                $('button').attr('disabled', 'disabled');
                $('#content').addClass('overlay');
                $('#absen-btn-action').html(
                    `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...`
                );
                $.ajax({
                    type: 'POST',
                    url: '/act/bulk-copy-presence',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        id_absen_kendaraan: IDabsenKendaraan,
                        id_absen_kendaraan_keterangan: IDketeranganKendaraan,
                        nm_keterangan: keterangan,
                        warna_symbol: warnaSymbol,
                        nilai: nilaiSymbol,
                        alasan: alasan,
                        start_date: startDate,
                        end_date: endDate,
                        date: date,
                    },
                    success: function(response) {
                        if (response.statusCode == 200) {
                            iziToast.success({
                                title: 'OK',
                                position: 'topRight',
                                message: response.message
                            });
                            location.reload();
                        } else {
                            iziToast.warning({
                                title: 'Oops',
                                position: 'topRight',
                                message: response.message
                            });
                            location.reload();
                        }
                    },
                    error: function() {
                        alert('silahkan hubungi admin')
                        location.reload();
                    }

                });
            }

            function presenceAction(ID, IDabsenKendaraan, IDketeranganKendaraan, date) {
                const element = $(`#${ID}`)
                const keterangan = $("input[name=keterangan]").val();
                const warnaSymbol = $("select[name=warna_symbol]").val();
                const nilaiSymbol = $("input[name=nilai_symbol]").val();
                const alasan = $("textarea[name=alasan]").val();

                if (!keterangan && !warnaSymbol && !nilaiSymbol) {
                    alert('Harap isi absen dengan benar')
                    return;
                }

                $('#absenActionModal').modal('hide');
                const html =
                    `<div style="background:${warnaSymbol};padding:10px">${keterangan}</div><div>${alasan ? `Alasan : <b>${alasan}</b>` :``}</div>`
                $('#absenActionModal').modal('hide');
                element.html(html);
                element.attr('onClick',
                    `showEditPresenceModal(this,"${IDabsenKendaraan}","${IDketeranganKendaraan}","${keterangan}","${warnaSymbol}","${nilaiSymbol}","${alasan}","${date}")`
                );

                $.ajax({
                    type: 'POST',
                    url: '/act/presence',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        id_absen_kendaraan: IDabsenKendaraan,
                        id_absen_kendaraan_keterangan: IDketeranganKendaraan,
                        nm_keterangan: keterangan,
                        warna_symbol: warnaSymbol,
                        nilai: nilaiSymbol,
                        alasan: alasan,
                        date: date,
                    },
                    error: function() {
                        element.text('').css('background', 'white');
                    }

                });

            }

            function inputBalanceAction(element, IDabsenKendaraan, IDketeranganKendaraan) {
                const x = $(element);
                const balanceValue = x.prev().val();
                if (!balanceValue) {
                    return alert('Mohon diisi dengan benar')
                }
                x.attr('disabled', 'disabled')
                x.parent().empty().append(balanceValue);


                $.ajax({
                    type: "post",
                    url: '/act/add-balance',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        id_absen_kendaraan: IDabsenKendaraan,
                        id_absen_kendaraan_keterangan: IDketeranganKendaraan,
                        saldo: balanceValue,
                    },

                });
            }

            function changeDateAction() {
                const startDate = $("input[name=start_date]").val();
                const endDate = $("input[name=end_date]").val();
                const diff = new Date(endDate) - new Date(startDate);
                if (diff <= 0) {
                    alert('End Date tidak boleh kurang atau sama dengan dari Start Date');
                }
                window.location.href = `/dashboard/absensi/{{ $daerah->code_daerah }}?start=${startDate}&end=${endDate}`;
            }
        </script>
    @endpush
@endsection
