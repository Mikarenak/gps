@extends('layouts.app')
@section('content')
    {{-- @dd($daerah->code_daerah); --}}
    <form method="POST" action="/act/add-kendaraan">
        @csrf
        <input type="hidden" name="id_daerah" value="{{ $daerah->id }}">
        <input type="hidden" name="code_daerah" value="{{ $daerah->code_daerah }}">
        <div class="mb-3">
            <label class="form-label">Nopol</label>
            <textarea name="nopol" class="form-control @error('nopol') is-invalid @enderror" required>{{ old('nopol') }}</textarea>
            @error('nopol')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>
        <div class="mb-3">
            <label class="form-label">Supir</label>
            <input name="nm_supir" type="text" class="form-control @error('nm_supir') is-invalid @enderror"
                value="{{ old('nm_supir') }}" required>
            @error('nm_supir')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>
        <button type="submit" class="btn btn-main">
            <i class="bi bi-save2"></i>&nbsp Submit
        </button>
    </form>
@endsection
