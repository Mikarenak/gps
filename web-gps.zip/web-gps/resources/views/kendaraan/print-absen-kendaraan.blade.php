<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Absensi {{ $daerah->nm_instansi }} {{ $daerah->nm_daerah }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<style>
    table>tbody>tr:nth-child(1) {
        background: #9D3C72;
        color: white;
    }
</style>

<body>
    <table class="table table-bordered table-responsive" id="absen-kendaraan-table">
        <tr>
            <td>NO</td>
            <td>NOPOL</td>
            <td>Supir</td>
            <td>KET</td>
            <td>SALDO</td>
            @foreach ($dates as $date)
                <td>{{ $date->format('d') }}</td>
            @endforeach
            <td>Total</td>
        </tr>
        @foreach ($listAbsenKendaraan as $absenKendaraan)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $absenKendaraan->nopol }}</td>
                <td>{{ $absenKendaraan->nm_supir }}</td>
                @php
                    $keterangan = $absenKendaraan->keteranganKendaraan->where('seq', 1)->first();
                    $subTotalAbsen = 0;
                    $saldo = !empty($keterangan->saldo) ? $keterangan->saldo->saldo : '';
                    $subTotalAbsen += (int) $saldo;
                @endphp
                <td>{{ $keterangan->nm_keterangan }}</td>
                <td>{{ $saldo }}</td>

                @foreach ($dates as $key => $value)
                    @if (!empty($keterangan->detail))
                        @php
                            $absen = $keterangan->detail->where('tanggal_absen', $value->format('Y-m-d'))->first();
                        @endphp
                        @if (!empty($absen))
                            @php
                                $subTotalAbsen += $absen->nilai;
                            @endphp
                            <td>
                                <div style="background:{{ $absen->warna_symbol }};padding:10px">
                                    {{ $absen->nm_keterangan }}
                                </div>
                                <div style="width: 70px;word-wrap: break-word">{!! $absen->alasan ? 'Alasan : <b>' . $absen->alasan . '</b>' : '' !!}</div>
                            </td>
                        @else
                            <td></td>
                        @endif
                    @else
                        <td></td>
                    @endif
                @endforeach
                <td><b>{{ $subTotalAbsen }}</b></td>
                {{-- <td>{{ $absenKendaraan->keterangan }}</td> --}}
            </tr>
            @foreach ($absenKendaraan->keteranganKendaraan->sortBy('seq') as $keterangan)
                @if (!$loop->first)
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        @php
                            $subTotalAbsen = 0;
                            $saldo = !empty($keterangan->saldo) ? $keterangan->saldo->saldo : '';
                            $subTotalAbsen += (int) $saldo;
                        @endphp
                        <td>{{ $keterangan->nm_keterangan }}</td>
                        <td>{{ $saldo }}</td>
                        @foreach ($dates as $key => $value)
                            @if (!empty($keterangan->detail))
                                @php
                                    $absen = $keterangan->detail->where('tanggal_absen', $value->format('Y-m-d'))->first();
                                @endphp
                                @if (!empty($absen))
                                    @php
                                        $subTotalAbsen += $absen->nilai;
                                    @endphp
                                    <td>
                                        <div style="background:{{ $absen->warna_symbol }};padding:10px">
                                            {{ $absen->nm_keterangan }}
                                        </div>
                                        <div style="width: 70px;word-wrap: break-word">{!! $absen->alasan ? 'Alasan : <b>' . $absen->alasan . '</b>' : '' !!}</div>
                                    </td>
                                @else
                                    <td>

                                    </td>
                                @endif
                            @else
                                <td></td>
                            @endif
                        @endforeach
                        <td><b>{{ $subTotalAbsen }}</b></td>
                        {{-- <td></td> --}}
                    </tr>
                @endif
            @endforeach
        @endforeach
    </table>
    <div class="mt-4">
        <h2>Keterangan Symbol</h2>
        <div class="row row-cols-2 my-3">
            @foreach ($symbols as $symbol)
                <div class="d-flex text-center mb-1">
                    <div class="me-2" style="width:50px;height:40px;background:{{ $symbol->warna_symbol }}">
                        {{ $symbol->nm_symbol }}
                    </div>
                    <p>: {{ $symbol->ket_symbol }}</p>
                </div>
            @endforeach
        </div>
    </div>

    <script>
        window.print();
    </script>
</body>

</html>
