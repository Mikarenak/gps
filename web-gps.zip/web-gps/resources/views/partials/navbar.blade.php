@php
    $listDaerah = App\Models\Daerah::where('nm_instansi', Auth::user()->instansi)->get();
@endphp

{{-- <nav>
    <h1 style="font-family: Inika;font-weight:700">PT. Sriwijaya Lintas</h1>
    <a href="/dashboard">Home</a>
    @foreach ($listDaerah as $daerah)
        <a href="/dashboard/absensi/{{ $daerah->code_daerah }}">{{ $daerah->nm_daerah }}</a>
    @endforeach
    <a class="link-danger" href="/sign-out">Log Out</a>
</nav> --}}

<!-- Sidebar -->
<div id="sidebar-wrapper">
    <ul class="sidebar-nav">
        <li class="sidebar-title">
            <a href="/">
                <img src="{{ asset('sln.png') }}" alt="" width="50" height="30">
                SRIWIJAYA GROUP
            </a>
            <hr style="width:100%;text-align:left;margin-left:0;color: rgb(255, 255, 255)">
        </li>
        <!-- <li class="sidebar-brand">
            <a href="/">
                <img src="{{ asset('brand.png') }}" alt="">
            </a>
        </li> -->
        <div id="sidebar-menus">
            @foreach ($listDaerah as $daerah)
                <li>
                    <a href="/dashboard/absensi/{{ $daerah->code_daerah }}">{{ $daerah->nm_daerah }}</a>
                </li>
            @endforeach
            <li>
                <a style="color: rgb(249, 154, 154)" href="/sign-out">Log Out</a>
            </li>
        </div>
    </ul>
</div>
<!-- /#sidebar-wrapper -->

<!-- Page Content -->
<!-- /#page-content-wrapper -->
<!-- /#wrapper -->
