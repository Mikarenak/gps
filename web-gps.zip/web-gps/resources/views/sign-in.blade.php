<!-- <div  style="background-image: url('{{ asset('bg2.png') }}');"> -->
@extends('layouts.app')
@section('content')
    @if (session()->has('failed'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('failed') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
        </div>
    @endif
    <div class="mt-5 form-row text-center">
        <img style="display: block;margin:auto" src="{{ asset('brand.png') }}" alt="">
    </div>
    <div class="container">
        <form method="POST" action="/sign-in">
            @csrf
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control @error('username') is-invalid @enderror"
                    value="{{ old('username') }}">
            </div>
            @error('username')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror"
                    id="exampleInputPassword1" value="{{ old('password') }}">
            </div>
            @error('password')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
            <button type="submit" class="btn btn-main" style="width: 100%">Sign In</button>
        </form>
    </div>
@endsection