@extends('layouts.app')
@section('content')
    <form method="POST" action="/act/edit-symbol">
        @csrf
        <input type="hidden" name="code_daerah" value="{{ $daerah->code_daerah }}">
        <input type="hidden" name="id_symbol" value="{{ $symbol->id_symbol }}">
        <div class="mb-3">
            <label class="form-label">Isi Simbol</label>
            <input type="text" name="nm_symbol" class="form-control @error('nm_symbol') is-invalid @enderror"
                value="{{ old('nm_symbol', $symbol->nm_symbol) }}" required>
            @error('nm_symbol')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>
        <div class="mb-3">
            <label class="form-label">Keterangan Simbol</label>
            <textarea name="ket_symbol" class="form-control @error('ket_symbol') is-invalid @enderror" required>{{ old('ket_symbol', $symbol->ket_symbol) }}</textarea>
            @error('ket_symbol')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>
        <div class="mb-3 form-check">
            <label class="form-label">Warna Simbol</label>
            <input name="warna_symbol" type="color"
                class="form-control form-control-color @error('warna_symbol') is-invalid @enderror"
                value="{{ old('warna_symbol', $symbol->warna_symbol) }}" required>
            @error('warna_symbol')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>
        <div class="mb-3">
            <label class="form-label">Nilai Simbol</label>
            <input type="number" name="value" class="form-control @error('value') is-invalid @enderror"
                value="{{ old('value', $symbol->value) }}" required>
            @error('value')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>
        <button type="submit" class="btn btn-main">
            <i class="bi bi-save2"></i>&nbsp Submit</button>
    </form>
@endsection
