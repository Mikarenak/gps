@extends('layouts.app')
@section('content')
    <h1>Halo {{ Auth::user()->display_name }}</h1>
    <p>Kamu sekarang login sebagai {{ Auth::user()->instansi }}</p>
@endsection
