<?php

use App\Http\Controllers\AbsenKendaraanController;
use App\Http\Controllers\SymbolController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [UserController::class, 'index'])->name('user.index');
Route::post('sign-in', [UserController::class, 'actionSignIn']);

Route::middleware(['web', 'auth'])->group(function () {
    Route::prefix('dashboard')->group(function () {
        Route::get('/', function () {
            return view('welcome');
        });
        Route::prefix('absensi/{namaDaerah}')->group(function () {
            Route::get('/', [AbsenKendaraanController::class, 'index']);
            Route::get('add-kendaraan', [AbsenKendaraanController::class, 'indexAdd']);
            Route::get('edit-kendaraan/{IDabsenKendaraan}', [AbsenKendaraanController::class, 'indexEdit']);
            Route::get('print', [AbsenKendaraanController::class, 'indexPrint']);
            Route::get('add-symbol', [SymbolController::class, 'indexAdd']);
            Route::get('edit-symbol/{IDsymbol}', [SymbolController::class, 'indexEdit']);
        });
        // Route::get('add-kendaraan/{namaDaerah}', [AbsenKendaraanController::class, 'indexAdd']);
        // Route::get('/', [AbsenKendaraanController::class, 'index']);
        // Route::get('add-symbol', [SymbolController::class, 'indexAdd']);
        // Route::get('add-kendaraan', [AbsenKendaraanController::class, 'indexAdd']);
    });

    // Route::post('/', [UserController::class, 'actionSignIn']);
    Route::prefix('dt')->group(function () {
        Route::post('absen-kendaraan', [AbsenKendaraanController::class, 'absenKendaraanList']);
    });

    Route::prefix('act')->group(function () {
        Route::post('add-symbol', [SymbolController::class, 'actionAddSymbol']);
        Route::post('edit-symbol', [SymbolController::class, 'actionEditSymbol']);
        Route::post('add-kendaraan', [AbsenKendaraanController::class, 'actionAddKendaraan']);
        Route::post('edit-kendaraan', [AbsenKendaraanController::class, 'actionEditKendaraan']);
        Route::post('presence', [AbsenKendaraanController::class, 'actionPresence']);
        Route::post('edit-presence', [AbsenKendaraanController::class, 'actionEditPresence']);
        Route::post('bulk-copy-presence', [AbsenKendaraanController::class, 'actionBulkCopyPresence']);
        Route::post('add-balance', [AbsenKendaraanController::class, 'actionAddBalance']);
    });
    Route::get('sign-out', [UserController::class, 'actionSignOut']);
});
