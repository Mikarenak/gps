<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Absensi <?php echo e($daerah->nm_instansi); ?> <?php echo e($daerah->nm_daerah); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<style>
    table>tbody>tr:nth-child(1) {
        background: #9D3C72;
        color: white;
    }
</style>

<body>
    <table class="table table-bordered table-responsive" id="absen-kendaraan-table">
        <tr>
            <td>NO</td>
            <td>NOPOL</td>
            <td>Supir</td>
            <td>KET</td>
            <td>SALDO</td>
            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($date->format('d')); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td>Total</td>
        </tr>
        <?php $__currentLoopData = $listAbsenKendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absenKendaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($absenKendaraan->nopol); ?></td>
                <td><?php echo e($absenKendaraan->nm_supir); ?></td>
                <?php
                    $keterangan = $absenKendaraan->keteranganKendaraan->where('seq', 1)->first();
                    $subTotalAbsen = 0;
                    $saldo = !empty($keterangan->saldo) ? $keterangan->saldo->saldo : '';
                    $subTotalAbsen += (int) $saldo;
                ?>
                <td><?php echo e($keterangan->nm_keterangan); ?></td>
                <td><?php echo e($saldo); ?></td>

                <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!empty($keterangan->detail)): ?>
                        <?php
                            $absen = $keterangan->detail->where('tanggal_absen', $value->format('Y-m-d'))->first();
                        ?>
                        <?php if(!empty($absen)): ?>
                            <?php
                                $subTotalAbsen += $absen->nilai;
                            ?>
                            <td>
                                <div style="background:<?php echo e($absen->warna_symbol); ?>;padding:10px">
                                    <?php echo e($absen->nm_keterangan); ?>

                                </div>
                                <div style="width: 70px;word-wrap: break-word"><?php echo $absen->alasan ? 'Alasan : <b>' . $absen->alasan . '</b>' : ''; ?></div>
                            </td>
                        <?php else: ?>
                            <td></td>
                        <?php endif; ?>
                    <?php else: ?>
                        <td></td>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td><b><?php echo e($subTotalAbsen); ?></b></td>
                
            </tr>
            <?php $__currentLoopData = $absenKendaraan->keteranganKendaraan->sortBy('seq'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keterangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$loop->first): ?>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <?php
                            $subTotalAbsen = 0;
                            $saldo = !empty($keterangan->saldo) ? $keterangan->saldo->saldo : '';
                            $subTotalAbsen += (int) $saldo;
                        ?>
                        <td><?php echo e($keterangan->nm_keterangan); ?></td>
                        <td><?php echo e($saldo); ?></td>
                        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!empty($keterangan->detail)): ?>
                                <?php
                                    $absen = $keterangan->detail->where('tanggal_absen', $value->format('Y-m-d'))->first();
                                ?>
                                <?php if(!empty($absen)): ?>
                                    <?php
                                        $subTotalAbsen += $absen->nilai;
                                    ?>
                                    <td>
                                        <div style="background:<?php echo e($absen->warna_symbol); ?>;padding:10px">
                                            <?php echo e($absen->nm_keterangan); ?>

                                        </div>
                                        <div style="width: 70px;word-wrap: break-word"><?php echo $absen->alasan ? 'Alasan : <b>' . $absen->alasan . '</b>' : ''; ?></div>
                                    </td>
                                <?php else: ?>
                                    <td>

                                    </td>
                                <?php endif; ?>
                            <?php else: ?>
                                <td></td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><b><?php echo e($subTotalAbsen); ?></b></td>
                        
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <div class="mt-4">
        <h2>Keterangan Symbol</h2>
        <div class="row row-cols-2 my-3">
            <?php $__currentLoopData = $symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex text-center mb-1">
                    <div class="me-2" style="width:50px;height:40px;background:<?php echo e($symbol->warna_symbol); ?>">
                        <?php echo e($symbol->nm_symbol); ?>

                    </div>
                    <p>: <?php echo e($symbol->ket_symbol); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <script>
        window.print();
    </script>
</body>

</html>
<?php /**PATH /Users/macos/Documents/Coding/Work/web-gps/resources/views/kendaraan/print-absen-kendaraan.blade.php ENDPATH**/ ?>