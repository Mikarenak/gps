<?php
    $listDaerah = App\Models\Daerah::where('nm_instansi', Auth::user()->instansi)->get();
?>



<!-- Sidebar -->
<div id="sidebar-wrapper">
    <ul class="sidebar-nav">
        <li class="sidebar-title">
            <a href="/">
                PT. Sriwijaya Lintas
            </a>
        </li>
        <li class="sidebar-brand">
            <a href="/">
                <img src="<?php echo e(asset('brand.png')); ?>" alt="">
            </a>
        </li>
        <div id="sidebar-menus">
            <?php $__currentLoopData = $listDaerah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daerah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="/dashboard/absensi/<?php echo e($daerah->code_daerah); ?>"><?php echo e($daerah->nm_daerah); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a style="color: rgb(249, 154, 154)" href="/sign-out">Log Out</a>
            </li>
        </div>
    </ul>
</div>
<!-- /#sidebar-wrapper -->

<!-- Page Content -->
<!-- /#page-content-wrapper -->
<!-- /#wrapper -->
<?php /**PATH /Users/macos/Documents/Coding/Work/web-gps/resources/views/partials/navbar.blade.php ENDPATH**/ ?>